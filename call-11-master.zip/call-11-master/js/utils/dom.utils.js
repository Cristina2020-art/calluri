
export function qs( query, element = document ) {
    return element.querySelector( query )
}
