<?php

$host = 'localhost';
$user = 'tod0resc1_project';
$pass = 'parolapentruproiect1';
$db = 'tod0resc1_project';
