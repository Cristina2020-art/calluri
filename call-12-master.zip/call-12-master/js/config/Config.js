
const Config = {
    DOMAIN: 'todorescu.com',
    API_URL: 'https://todorescu.com/call-11/api/'
}

export default Config
