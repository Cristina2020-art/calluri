
import { qs, redirect } from './dom.utils.js'

window.qs = qs
window.redirect = redirect
