
import Component from '../Component.js'

export default class extends Component {
    constructor() {
        super({ templateContent: '<h3>counter</h3>' })
    }
}
