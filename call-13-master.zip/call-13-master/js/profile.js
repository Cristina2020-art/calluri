import UserCard from './components/user-card/user-card.js'
import Counter from './components/counter/counter.js'

window.customElements.define( 'user-card', UserCard )
window.customElements.define( 'app-counter', Counter )
