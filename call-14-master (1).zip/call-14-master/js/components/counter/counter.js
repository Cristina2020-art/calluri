
import WebComponent from '../WebComponent.js'

export default class extends WebComponent {
    constructor() {
        super({ templateContent: '<h3>counter</h3>' })
    }
}
